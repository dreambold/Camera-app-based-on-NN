from logger import *

def AddonFunction2():
	#print ('Addon Function started 2')
	pass

def AddonFunction():
	#print ('Addon Function started')
	#WriteLog('Addon Function started\n')
	AddonFunction2()