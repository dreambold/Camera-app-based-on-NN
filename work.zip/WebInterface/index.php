<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <link rel="icon" type="image/svg+xml" href="config/favicon.svg" sizes="any">
    <link rel="icon" type="image/png" href="config/favicon.png" sizes="96x96">
    <link rel="stylesheet" type="text/css" href="config/style_imageloader.css">
    <title>Inventocam Menu</title>
  </head>
  <body>
  <div id="uploadcontainer">
  	<a href="annotate/" class="buttonlink"><div class="question full">Annotate</div></a>
  	<a href="uploads/" class="buttonlink"><div class="question full">Upload</div></a>
  </div>
  </body>
  
</html>