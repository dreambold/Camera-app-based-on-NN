# Inventocam
An inventory making camera app based on an neural network
