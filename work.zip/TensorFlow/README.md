Here we'll add the Tensorflow Code and configuration WITHOUT model and media (i.e. images, maybe videos) as those will be huge.
